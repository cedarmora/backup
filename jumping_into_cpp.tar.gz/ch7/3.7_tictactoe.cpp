//Lets two people play tic tac toe against each other.
//Has essentially no safeguards. It's mostly a medium,
//It doesn't know when someone has won or if somebody made an illegal move.
//:BROKEN: 

#include <iostream>
#include <string>

enum TicTacToeSquare { TTTS_BLANK, TTTS_O, TTTS_X };

int main()
{
	std::string player1, player2;
	TicTacToeSquare board[ 9 ];

	for (int i = 0; i <= 8; ++i)
		board[i] = TTTS_BLANK;

	std::cout << "Enter player one's name: ";
	std::cin >> player1;
	std::cout << "Enter player two's name: ";
	std::cin >> player2;

	//Gives only nine turns total, five for one player, four for the other.
	for (int i = 1; i <= 9; ++i)
	{
		if  (i % 2 == 1)
			std::cout << player1 << "'s turn.\n";
		else 
			std::cout << player2 << "'s turn.\n";
		//print board
		std::cout << board [0] << " | " << board [1] << " | " << board [2] << "\n";
		std::cout << "---------\n";
		std::cout << board [3] << " | " << board [4] << " | " << board [5] << "\n";
		std::cout << "---------\n";
		std::cout << board [6] << " | " << board [7] << " | " << board [8] << "\n";
	}
}
