#include <iostream>
#include <string>

char constexpr const * const verses[]
{
  "A Partridge in a Pear Tree.\n\n",
  "Two Turtle Doves\n",
  "Three French Hens\n",
  "Four Calling Birds\n",
  "Five Golden Rings\n",
  "Six Geese a Laying\n",
  "Seven Swans a Swimming\n",
  "Eight Maids a Milking\n",
  "Nine Ladies Dancing\n",
  "Ten Lords a Leaping\n",
  "Eleven Pipers Piping\n",
  "Twelve Drummers Drumming\n",
  "and a Partridge in a Pear Tree\n\n"
};

char constexpr const * const ordinal[]
{
  "first",
  "second",
  "third",
  "fourth",
  "fifth",
  "sixth",
  "seventh",
  "eighth",
  "ninth",
  "tenth",
  "eleventh",
  "twelfth"
};

int main()
{
  for(int i{}; i < 12; ++i)
  {
    std::cout << "On the " << ordinal[i]
              << " day of Christmas my true love sent to me:\n";
    for(int k{ i }; k >= 0; --k)
    { std::cout << verses[k]; }
  }
}