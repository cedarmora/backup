//Outputs lyrics to twelve days of Christmas.

#include <iostream>
#include <string>

using namespace std;

void outputChorus(int day);
void outputVerses(int day);

int main()
{
	for (int i = 1; i <=12; i++)
	{
		outputChorus(i);
		outputVerses(i);
	}
	return 0;
}

void outputVerses(int day)
{
	switch (day)
	{
	case 12:
		cout << "Twelve Drummers Drumming\n";
	case 11:
		cout << "Eleven Pipers Piping\n";
	case 10:
		cout << "Ten Lords a Leaping\n";
	case 9:
		cout << "Nine Ladies Dancing\n";
	case 8:
		cout << "Eight Maids a Milking\n";
	case 7:
		cout << "Seven Swans a Swimming\n";
	case 6:
		cout << "Six Geese a Laying\n";
	case 5:
		cout << "Five Golden Rings\n";
	case 4:
		cout << "Four Calling Birds\n";
	case 3:
		cout << "Three French Hens\n";
	case 2:
		cout << "Two Turtle Doves\n";
	case 1:
		if (day == 1)
			cout << "A Partridge in a Pear Tree.\n\n";
		else
			cout << "and a Partridge in a Pear Tree\n\n";
	}
}

void outputChorus(int day)
{
	string ordinal[12];
	ordinal[0] = "first";
	ordinal[1] = "second";
	ordinal[2] = "third";
	ordinal[3] = "fourth";
	ordinal[4] = "fifth";
	ordinal[5] = "sixth";
	ordinal[6] = "seventh";
	ordinal[7] = "eighth";
	ordinal[8] = "ninth";
	ordinal[9] = "tenth";
	ordinal[10] = "eleventh";
	ordinal[11] = "twelfth";

	cout << "On the " <<  ordinal[day - 1] << " day of Christmas my true love sent to me:\n";
}
