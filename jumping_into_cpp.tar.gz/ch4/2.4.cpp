//Password checker.
#include <iostream>

using namespace std;

int main ()
{
	int password;	
	cout << "Enter your password: ";
	cin >> password;
	if ( password == 1234 || password == 4321 )
	{
		cout << "Yaaaay!" << "\n";
	}
	else
	{
		cout << "Awwwww." << "\n";
	}
	return 0;
}
