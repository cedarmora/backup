//Password checker 2.0, based upon 4.2.cpp

#include <iostream>
#include <string>

using namespace std;

int main ()
{
	string username;
	string password;	
	cout << "Enter your username: ";
	cin >> username;
	cout << "Enter your password: ";
	cin >> password;
	if (username == "Bob" && password == "password" )
		cout << "Yaaaay!" << "\n";
	else if ( username == "John" && password == "derp" )
		cout << "Yaaaay!" << "\n";
	else if ( username == "Baobob" && password == "oops" )
		cout << "Yaaaay!" << "\n";
	else
		cout << "Awwwww." << "\n";
	return 0;
}
