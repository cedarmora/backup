//Takes inputted ages of two people, and says which is older. If both of them are over 100,
//tells them that they're super old.

#include <iostream>

using namespace std;

int main ()
{
	int person1, person2;
	cout << "Enter one person's age, followed by the other's age:\n";
	cin >> person1 >> person2;
	cout << "\n";
	if ( person1 > person2 )
		cout << "The first person is older.\n";
	else if ( person2 > person1 )
		cout << "The second person is older.\n";
	if (person1 > 100 && person2 > 100 )
		cout << "You're both super old!\n";
	return 0;
}
