//A calculator, taking first which operator to use, then the two numbers upon which to perform the operation.

#include <iostream>

using namespace std;

int main ()
{
	char op;
	int firstNumber;
	int secondNumber;
	cout << "Which operator would you like to use?\n";
	cin >> op;
	cout << "Enter the first number, followed by the second number.\n";
	cin >> firstNumber >> secondNumber;
	cout << "Your answer is: ";
	if ( op == '+' )
		cout << firstNumber + secondNumber << endl;
	if ( op == '-' )
		cout << firstNumber - secondNumber << endl;
	if ( op == '*' )
		cout <<  firstNumber * secondNumber << endl;
	if ( op == '/' )
		cout <<  firstNumber / secondNumber << endl;
	return 0;
}
