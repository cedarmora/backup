#include <iostream>

using namespace std;

int main ()
{
	cout << "Richard" << endl;
	cout << "Sam" << endl;
	cout << "Orpheon" << endl;
}
