#include <iostream>

using namespace std;

int main ()
{
	//This is 2.cpp, commented out to show that it stops it from working
	/*
	cout << "Richard" << endl;
	cout << "Sam" << endl;
	cout << "Orpheon" << endl;
	*/
}
