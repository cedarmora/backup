//A menu program that lets users select from a list of options.

#include <iostream>
#include <string>

void calculator();
void bottlesOfBeer();
void displayNumbersSquared();

int main()
{
	int pickedOption;
	//Loop checks if input is menu item.
	do 
	{
		//This while loop checks for valid input.
		while 
		(
			(std::cout << "Pick an option:\n"
				   << "1: Start calculator.\n"
				   << "2: Display Bottles of Beer lyrics.\n"
				   << "3: Display 1-20 squared.\n"
			)  && !(std::cin >> pickedOption)
		)
		{
			std::cout << "Invalid input. Try again.\n";
			std::cin.clear();
			std::cin.ignore(100, '\n');
		} //End input type checking.
		
		if (pickedOption != 1 && pickedOption != 2 && pickedOption != 3)
		{
			std::cout << "That's not a menu item\n";
		}
	} while (pickedOption != 1 && pickedOption != 2 && pickedOption != 3);

		switch (pickedOption)
		{
		case 1:
			calculator();
			break;
		case 2:
			bottlesOfBeer();
			break;
		case 3:
			displayNumbersSquared();
			break;
		default:
			std::cout << "That wasn't a menu option.";
		}
	return 0;
}

void calculator()
{
	char op;
	int firstNumber;
	int secondNumber;
	std::cout << "Which operator would you like to use?\n";
	std::cin >> op;
	std::cout << "Enter the first number, followed by the second number.\n";
	std::cin >> firstNumber >> secondNumber;
	std::cout << "Your answer is: ";
	if (op == '+')
		std::cout << firstNumber + secondNumber << "\n";
	if (op == '-')
		std::cout << firstNumber - secondNumber << "\n";
	if (op == '*')
		std::cout <<  firstNumber * secondNumber << "\n";
	if (op == '/')
		std::cout <<  firstNumber / secondNumber << "\n";
}

void bottlesOfBeer()
{
	int i = 99;
	while (i > 0)
	{
		std::cout << i << " bottles of beer on the wall, " << i << " bottles of beer.\n";
		std::cout << "Take one down, pass it around, " << --i << " bottles of beer on the wall.\n";
	}
}

void displayNumbersSquared()
{
	for (int i = 1; i <=20; ++i)
	{
		std::cout << i*i << "\n";
	}
}
