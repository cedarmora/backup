//Calculator, with functions!
#include <iostream>

using namespace std;

void add(double firstNumber, double secondNumber);
void subtract(double firstNumber, double secondNumber);
void multiply(double firstNumber, double secondNumber);
void divide(double firstNumber, double secondNumber);

int main()
{
	char op;
	double firstNumber;
	double secondNumber;
	cout << "Which operator would you like to use?\n";
	cin >> op;
	cout << "Enter the first number, followed by the second number.\n";
	cin >> firstNumber >> secondNumber;
	cout << "Your answer is: ";
	if (op == '+')
		add(firstNumber, secondNumber);
	if (op == '-')
		subtract(firstNumber, secondNumber);
	if (op == '*')
		multiply(firstNumber, secondNumber);
	if (op == '/')
		divide(firstNumber, secondNumber);
	return 0;
}

void add(double firstNumber, double secondNumber)
{
	cout << firstNumber + secondNumber << "\n";
}

void subtract(double firstNumber, double secondNumber)
{
	cout << firstNumber - secondNumber << "\n";
}
void multiply(double firstNumber, double secondNumber)
{
	cout <<  firstNumber * secondNumber << "\n";
}
void divide(double firstNumber, double secondNumber)
{
	cout <<  firstNumber / secondNumber << "\n";
}
