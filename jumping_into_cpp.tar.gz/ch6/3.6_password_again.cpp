//Password checker that gives limited tries before locking, now with functions!

#include <iostream>
#include <string>

using namespace std;

bool isCorrectPassword(string password);

int main()
{
	string password;
	bool result;
	cout << "Enter your password: ";
	result = isCorrectPassword(password);
	if (result)
	{
		cout << "Yay!\n";
	}
	else 
	{
		cout << "You get the infinite loop of doooooooooooooom muahahahahaha";
		while (1)
			cout << "hahahahahahahaahahahahahahahahahaha\n";
	}
}

bool isCorrectPassword(string password)
{
	for ( int i = 10; i > 0; --i )
	{
		cin >> password;
		if ( password == "bla" )
		{
			return true;
		}
		else
		{	
			cout << "Try again. You have " << i - 1 << " tries left.\n";
		}
	}
	return false;
}
