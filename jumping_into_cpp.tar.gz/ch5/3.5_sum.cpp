//Computes a running sum of inputs until user inputs 0 aka zero.

#include <iostream>

using namespace std;

int main ()
{
	int total = 0;
	int userInput = 1;

	while (userInput !=0)
	{
		cout << "Enter number to add to the total: ";
		cin >> userInput;
		total += userInput;
		cout << "Total = " << total << endl;
	}
	return 0;
}
