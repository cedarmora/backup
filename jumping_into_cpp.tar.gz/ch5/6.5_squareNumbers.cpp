//Displays first 20 square numbers.

#include <iostream>

using namespace std;

int main ()
{
	for ( int i = 1; i <=20; ++i )
	{
		cout << i*i << endl;
	}
}
