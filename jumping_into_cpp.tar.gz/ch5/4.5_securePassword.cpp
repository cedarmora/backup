//Password checker that gives limited tries before locking.

#include <iostream>
#include <string>

using namespace std;

int main ()
{
	string password;
	cout << "Enter your password: ";
	for ( int i = 10; i > 0; --i )
	{
		cin >> password;
		if ( password == "bla" )
		{
			break;
		}
		else
		{	
			cout << "Try again. You have " << i - 1 << " tries left.\n";
		}
	}
	if ( password == "bla" )
	{
		cout << "Yay!\n";
	}
	else if ( password != "bla" )
	{
		cout << "You get the infinite loop of doooooooooooooom muahahahahaha";
		while (1)
			cout << "hahahahahahahaahahahahahahahahahaha\n";
	}
}
