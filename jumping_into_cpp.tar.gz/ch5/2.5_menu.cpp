//A menu program that lets users select from a list of options.

#include <iostream>

using namespace std;

int main ()
{
	int pickedOption;
	do 
	{
	cout << "Pick an option:\n";
	cout << "1: Eat the cracker\n";
	cout << "2: Smell the cracker\n";
	cout << "3: Sit on the cracker\n";
	cout << "4: Crack the cracker\n";
	cin >> pickedOption;
	} while ( pickedOption != 1 && pickedOption != 2 && pickedOption != 3 && pickedOption != 4 ); 
	cout << "Yay! You picked a correct option!\n";
	return 0;
}
