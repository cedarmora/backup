//Prints full lyrics of 99 Bottles of Beer
#include <iostream>

using namespace std;

int main ()
{
	int i = 99;
	while ( i > 0 )
	{
		cout << i << " bottles of beer on the wall, " << i << " bottles of beer.\n";
		cout << "Take one down, pass it around, " << --i << " bottles of beer on the wall.\n";
	}
}

