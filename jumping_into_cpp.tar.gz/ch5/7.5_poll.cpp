//A poll program that lets you enter your question and three possible answers. Then people can vote by choosing
//answer 1, 2, or 3.

#include <iostream>
#include <string>

using namespace std;

string makeGraphRow (int results)
{
	//Concatenates results number of | and outputs that number.
	//for the purpose of display in a graph.
	string row;
	for (int i = results; i > 0; --i)
	{
		row += "|";
	}
	return row;
}

int main ()
{
	string question; 
	int answer;
	int results1 = 0, results2 = 0, results3 = 0;
	string option1, option2, option3;
	
	cout << "Enter your question, which should have three possible answers:\n";
	getline (cin, question);

	cout << "Enter each of the three possible answers sequentially:\n"; 
	getline (cin, option1);
	getline (cin, option2);
	getline (cin, option3);

	cout << "\n\nBeginning Poll:\n\n";
	do
	{
		cout << question << "\n\n";
		cout << "1: " << option1 << "\n";
		cout << "2: " << option2 << "\n";
		cout << "3: " << option3 << "\n\n";
		cout << "Pick your answer.\n";
		cin >> answer;
		if (answer != 0 && answer != 1 && answer != 2 && answer != 3)
		{
			cout << "Bad input, try again.\n";
			continue;
		}
		if (answer == 1)
		{
			results1++;
		}
		else if (answer == 2)
		{
			results2++;
		}
		else if (answer == 3)
		{
			results3++;
		}
	} while (answer != 0);

	cout << "\n\nResults:\n";
	cout << "The first answer was chosen " << results1 << " times.\n";
	cout << "The second answer was chosen " << results2 << " times.\n";
	cout << "The third answer was chosen " << results3 << " times.\n";

	cout << "Here is a graph of the results!\n\n";
	cout << "   123456789\n";	
	cout << "1: " << makeGraphRow (results1) << endl;
	cout << "2: " << makeGraphRow (results2) << endl;
	cout << "3: " << makeGraphRow (results3) << endl; 
}
