//Takes two numbers from a user and displays the sum of the two numbers
#include <iostream>

using namespace std;

int main ()
{
	int number1;
	int number2;
	cout << "Number Summer 1.0" << endl <<endl;
	cout << "Enter a number: ";
	cin >> number1;
	cout << "Enter another number: ";
	cin >> number2;
	cout << number1 << " + " << number2 << " = " << number1 + number2 << endl;
}
