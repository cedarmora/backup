//Accurate division machine

#include <iostream>

using namespace std;

int main ()
{
	double numerator;
	double denominator;
	cout << "Division Machine 1.0" << endl;
	cout << "Enter the numerator: ";
	cin >> numerator;
	cout << "Enter the denominator: ";
	cin >> denominator;
	cout << numerator << " / " << denominator << " = " << numerator / denominator << endl;
}
